# Codex Pet Watch

把 Codex 用量显示到 Wear OS 手表上的小工具。项目包含一个 Windows 本地用量服务和一个原生 Wear OS 表盘式应用。

## 项目组成

- `server/`：Windows 本地用量 API，内置 Codex CLI 用量读取器。
- `wear-app/`：Wear OS Android 应用，内置宠物动画和用量仪表盘。
- `watch-ui-*.html`：早期界面原型，可作为设计参考。
- `scripts/create-source-package.ps1`：生成可公开上传的源码包。

核心用量读取代码已经包含在 `server/codex_usage_reader.py`，不再依赖外部 CodexBar 项目。

## 开源前说明

仓库默认不保存私人信息。以下内容会被 `.gitignore` 和源码打包脚本排除：

- `config.local.ps1`
- `codex-watch-token.txt`
- `wear-app/local.properties`
- 日志、pid、APK、构建产物
- 本机 `tools/` 工具链缓存
- 手动验证截图

发布到 GitHub 前请再确认两件事：

1. 添加你希望使用的开源许可证，例如 MIT、Apache-2.0 或 GPL。
2. 确认 `wear-app/app/src/main/assets/pets/` 里的宠物素材可以公开分发。

## 准备环境

需要：

- Windows + PowerShell
- Python 3.10+
- JDK 17+
- Android SDK / platform-tools，可由 Android Studio 安装
- Wear OS 手表，开启 USB 调试

如果你保留了本机 `tools/` 目录，脚本会优先使用里面的 JDK、Android SDK、Gradle 和 ADB。公开仓库不需要上传这个目录。

## 第一次配置

复制本地配置模板：

```powershell
Copy-Item .\config.example.ps1 .\config.local.ps1
notepad .\config.local.ps1
```

通常不需要填写读取器路径。服务默认读取当前用户的：

```text
~\.codex
```

如果 Codex 数据目录不在默认位置，可填写：

```powershell
$env:CODEX_WATCH_CODEX_DIR = "C:\path\to\.codex"
```

可选填写：

```powershell
$env:CODEX_WATCH_PUBLIC_URL = "https://your-domain.example.com/usage"
$env:CODEX_WATCH_LAN_URL = "http://YOUR_PC_IP:8765/usage"
$env:CODEX_WATCH_TOKEN = ""
```

`CODEX_WATCH_TOKEN` 留空时，服务启动脚本会自动生成 `codex-watch-token.txt`。

## 启动用量服务

前台运行：

```powershell
.\server\run-codex-watch-server.ps1
```

后台运行：

```powershell
.\start-codex-watch-server.ps1
```

服务接口：

```text
http://127.0.0.1:8765/health
http://127.0.0.1:8765/usage
```

用量读取器只读取：

```text
~\.codex\config.toml
~\.codex\sessions\**\*.jsonl
```

它不会读取浏览器数据、cookies、OpenAI auth token 或 Claude 文件，也不会启动 Codex 进程。

用量样本超过 5 分钟没有更新时，手表会显示 `STALE`。手表每 5 分钟自动刷新一次，重新打开应用或点击表盘也会刷新。

## 配置手表应用地址

进入手表应用目录：

```powershell
cd .\wear-app
```

如果已经在 `config.local.ps1` 里填写了 `CODEX_WATCH_PUBLIC_URL` 或 `CODEX_WATCH_LAN_URL`，直接运行：

```powershell
.\set-watch-server-url.ps1
```

也可以手动传入地址和 token：

```powershell
.\set-watch-server-url.ps1 -Urls https://YOUR_PUBLIC_DOMAIN/usage,http://YOUR_PC_IP:8765/usage,http://127.0.0.1:8765/usage -Token YOUR_TOKEN
```

地址会从左到右依次尝试。推荐顺序是公网隧道、局域网地址、USB 回退地址。

回到项目根目录：

```powershell
cd ..
```

## 构建和安装

构建调试 APK：

```powershell
.\build-apk.ps1
```

APK 输出位置：

```text
wear-app\app\build\outputs\apk\debug\app-debug.apk
```

安装到已连接的手表：

```powershell
.\install-to-watch.ps1
```

安装脚本会准备 ADB 反向隧道，让手表在 USB 调试时访问：

```text
http://127.0.0.1:8765/usage
```

## Cloudflare 隧道

如果想让手表离开局域网后继续同步，可以设置 Cloudflare 隧道 token：

```powershell
$env:CLOUDFLARED_TUNNEL_TOKEN = "YOUR_TUNNEL_TOKEN"
.\start-codex-watch-tunnel.ps1
```

也可以把 token 写进 `config.local.ps1`。没有 token 时脚本会尝试启动临时 Quick Tunnel。

## 生成公开源码包

生成一个排除私人文件和大体积缓存的 zip：

```powershell
.\scripts\create-source-package.ps1
```

输出：

```text
dist\codex-watch-pet-source.zip
```

这个包适合直接检查后上传到 GitHub。使用 Git 上传时，也请确认 `.gitignore` 生效。
